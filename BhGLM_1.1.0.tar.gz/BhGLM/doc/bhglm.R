## ----setup, include = FALSE----------------------------------------------
knitr::opts_chunk$set(
  eval = F,
  collapse = TRUE,
  comment = "#>"
)

## ----eval=F--------------------------------------------------------------
#  # fake data
#  age = rnorm(50, 30, 0.1)
#  sex = sample(x = c("male", "female"), size = 50, replace = T, prob = c(0.5, 0.5))
#  diet = sample(x = c(1, 5), size = 50, replace = T, prob = c(0.3, 0.7))
#  race = sample(c("Asian", "White", "Black"), size = 50, replace = T, prob = c(0.2, 0.4, 0.4))
#  
#  x.con = age # continuous variable
#  x.cat = cbind(sex, diet, race) # categorical variables
#  
#  x.con[1:2] = NA
#  x.cat[1,] = NA
#  
#  x1 = covariates(x.con = x.con, x.cat = x.cat, con.rescale = F, cat.center = F,
#                  fill.missing = T)
#  x1
#  x2 = covariates(x.con = x.con, x.cat = x.cat, con.rescale = T, cat.center = F,
#                  fill.missing = T)
#  x2
#  x3 = covariates(x.con = x.con, x.cat = x.cat, con.rescale = T, cat.center = T,
#                  fill.missing = T)
#  x3

## ----eval=F--------------------------------------------------------------
#  data(fake.cv) #load data from BhGLM
#  cov1 = fake.cv[, 3, drop = F] #get the first covariate
#  geno = fake.cv[, -c(1:4)] #get genotype data
#  x.main = make.main(geno = geno, model = "Cockerham", fill.missing = T)
#  x.GxE = make.inter(cov1, x.main, back = 0) #interactions between cov1 and all main effects
#  x.GxG1 = make.inter(x.main[, 1:10], x.main[, 11:20], back = 1) # some GxG interactions
#  x.GxG2 = make.inter(x.main, x.main, back = 1) # all GxG interactions

## ----eval=F--------------------------------------------------------------
#  ## Example 1: genetic association studies
#  data(fake.cv) #load data from BhGLM
#  geno = fake.cv[, -c(1:4)] #get genotype data
#  x = make.main(geno = geno, model = "additive", fill.missing = T)
#  x = make.main(geno = geno, model = "Cockerham", fill.missing = T, ind.group = fake.cv$y1)
#  
#  ## Example 2: QTL mapping in experimental crosses
#  require(qtl)
#  require(qtlbim)
#  data(listeria)
#  listeria
#  x = make.main(geno = listeria, model = "Cockerham", fill.missing = T, geno.order = F, loci.names = "position")
#  ## then we can follow the example in bglm to detect QTL

## ------------------------------------------------------------------------
#  library(BhGLM)
#  library(survival)
#  
#  N = 1000
#  K = 100
#  x = sim.x(n=N, m=K, corr=0.6) # simulate correlated continuous variables
#  h = rep(0.1, 4) # assign four non-zero main effects to have the assumed heritabilty
#  nz = as.integer(seq(5, K, by=K/length(h))); nz
#  yy = sim.y(x=x[, nz], mu=0, herit=h, p.neg=0.5) # simulate responses
#  yy$coefs
#  
#  y = yy$y.surv
#  d = table(y[,2]); d[1]/sum(d) # cencoring proportion
#  
#  
#  # jointly update
#  # Compare with conventional and ridge Cox model
#  par(mfrow = c(2, 2), cex.axis = 1, mar = c(3, 4, 4, 4))
#  gap = 10
#  
#  ps = 0.05
#  f1 = bcoxph(y ~ ., data = x, prior = "de", prior.scale = ps)
#  # summary.bh(f1)
#  plot.bh(f1, threshold = 0.01, gap = gap, main = "Cox with double-exponential")
#  
#  f2 = bcoxph(y ~ ., data = x, prior = "t", prior.scale = ps/1.4)
#  # summary.bh(f2)
#  plot.bh(f2, threshold = 0.01, gap = gap, main = "Cox with t")
#  
#  ss = c(0.04, 0.5)
#  f3 = bcoxph(y ~ ., data = x, prior = "mde", ss = ss)
#  # summary.bh(f3)
#  plot.bh(f3, threshold = 0.01, gap = gap, main = "Cox with mixture double exponential")
#  
#  ss = c(0.04, 0.5)
#  f4 = bcoxph(y ~ ., data = x, prior = "mt", ss = ss)
#  # summary.bh(f4)
#  plot.bh(f4, threshold = 0.01, gap = gap, main = "Cox with mixture t")
#  
#  
#  # group-wise update
#  ps = 0.05
#  f1 = bcoxph(y ~ ., data = x, prior = "de", method.coef = 50, prior.scale = ps)
#  #summary.bh(f1)
#  plot.bh(coefs = f2$coefficients, threshold = 10, gap = gap)

## ------------------------------------------------------------------------
#  N = 1000
#  K = 100
#  x = sim.x(n=N, m=K, corr=0.6) # simulate correlated continuous variables
#  h = rep(0.1, 4) # assign four non-zero main effects to have the assumed heritabilty
#  nz = as.integer(seq(5, K, by=K/length(h))); nz
#  yy = sim.y(x=x[, nz], mu=0, herit=h, p.neg=0.5, sigma=1.6, theta=2) # simulate responses
#  yy$coefs
#  
#  
#  # y = yy$y.normal; fam = gaussian; y = scale(y)
#  # y = yy$y.ordinal; fam = binomial
#  y = yy$y.nb; fam = NegBin
#  
#  # jointly fit all variables (can be slow if m is large)
#  par(mfrow = c(2, 2), cex.axis = 1, mar = c(3, 4, 4, 4))
#  gap = 10
#  
#  ps = 0.05
#  f1 = bglm(y ~ ., data = x, family = fam, prior = "de", prior.scale = ps)
#  plot.bh(f1, vars.rm = 1, threshold = 0.01, gap = gap, main = "de")
#  
#  f2 = bglm(y ~ ., data = x, family = fam, prior = "t", prior.scale = ps/1.4)
#  plot.bh(f2, vars.rm = 1, threshold = 0.01, gap = gap, main = "t")
#  
#  ss = c(0.04, 0.5)
#  f3 = bglm(y ~ ., data = x, family = fam, prior = "mde", ss = ss)
#  plot.bh(f3, vars.rm = 1, threshold = 0.01, gap = gap, main = "mde")
#  
#  ss = c(0.04, 0.5)
#  f4 = bglm(y ~ ., data = x, family = fam, prior = "mt", ss = ss, prior.df=Inf)
#  plot.bh(f4, vars.rm = 1, threshold = 0.01, gap = gap, main = "mt")
#  
#  
#  # group-wise update (can be much faster if m is large)
#  ps = 0.05
#  f1 = bglm(y ~ ., data = x, family = fam, prior = "de", method.coef = 50, prior.scale = ps) # update 50 coefficients at a time
#  plot.bh(f1, vars.rm = 1, threshold = 0.01, gap = gap)

## ------------------------------------------------------------------------
#  library(BhGLM)
#  library(survival)
#  library(glmnet)
#  
#  
#  N = 1000
#  K = 100
#  x = sim.x(n=N, m=K, corr=0.6) # simulate correlated continuous variables
#  h = rep(0.1, 4) # assign four non-zero main effects to have the assumed heritabilty
#  nz = as.integer(seq(5, K, by=K/length(h))); nz
#  yy = sim.y(x=x[, nz], mu=0, herit=h, p.neg=0.5, sigma=1.6) # simulate responses
#  yy$coefs
#  
#  # y = yy$y.normal; fam = "gaussian"; y = scale(y)
#  # y = yy$y.ordinal; fam = "binomial"
#  y = yy$y.surv; fam = "cox"
#  
#  group = NULL
#  #group = rep(0, 21)
#  #for(j in 1:length(group)) group[j] = (j-1) * K/(length(group)-1)
#  
#  # lasso and mixture lasso
#  
#  f1 = glmNet(x, y, family = fam, ncv = 1)
#  
#  ps = f1$prior.scale; ps
#  ss = c(ps, 0.5)
#  f2 = bmlasso(x, y, family = fam, prior = "mde", ss = ss, group = group)
#  
#  par(mfrow = c(1, 2), mar = c(3, 4, 4, 4))
#  gap = 10
#  plot.bh(coefs = f1$coef, threshold = f1$df, gap = gap, main = "lasso")
#  plot.bh(coefs = f2$coef, threshold = f2$df, gap = gap, main = "mixture lasso")

## ------------------------------------------------------------------------
#  library(BhGLM)
#  
#  
#  N = 1000
#  K = 100
#  x = sim.x(n = N, m = K, corr = 0.6) # simulate correlated variables
#  x = as.matrix(x)
#  h = rep(0.1, 4) # assign non-zero effects to have the assumed heritabilty
#  nz = as.integer(seq(5, K, by=K/length(h))); nz
#  yy = sim.y(x=x[, nz], mu = 10, herit=h, p.neg=0.5, sigma=1.6, quantiles = c(0.3, 0.6)) # simulate responses
#  yy$coefs
#  y = as.factor(yy$y.ordinal)
#  table(y)
#  
#  
#  par(mfrow = c(1, 3), cex.axis = 1, mar = c(3, 4, 4, 4))
#  # classical ordered logistic regression
#  library(MASS)
#  f1 = polr(y ~ ., data = x, Hess = T)
#  plot.bh(f1, gap = 5)
#  summary.bh(f1)
#  
#  # equivalent to classical ordered logistic regression
#  f2 = bpolr(y ~ ., data = x, prior.scale = Inf)
#  plot.bh(f2, gap = 5)
#  summary.bh(f2)
#  
#  # hierarchical ordered logistic regression
#  f3 = bpolr(y ~ ., data = x, prior.scale = 0.05)
#  plot.bh(f3, gap = 5)
#  summary.bh(f3)

