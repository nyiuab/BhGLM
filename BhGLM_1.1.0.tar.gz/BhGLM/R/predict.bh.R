

predict.bh <- function (object, new.x, new.y, offset = 0) 
{
  if (any(class(object) %in% "glmNet") | any(class(object) %in% "bmlasso")){
    family <- object$family
    if (family == "gaussian") object$family <- gaussian(link = "identity")
    if (family == "binomial") object$family <- binomial(link = "logit")
    if (family == "poisson") object$family <- poisson(link = "log")
    class(object) <- "glm"
    if (family == "cox") class(object) <- "coxph" 
  }
  if (missing(new.x) | missing(new.y)) {
    y <- object$y
    lp <- object$linear.predictors
    if (any(class(object) %in% "polr")) lp <- object$lp
  }
  else {
    y <- new.y
    x <- as.matrix(new.x)
    if (is.vector(new.x)) x <- t(as.matrix(new.x))
    coefs <- object$coefficients
    if (names(coefs)[1] == "(Intercept)") x <- cbind(1, x)
    if (is.null(offset) | missing(offset)) offset <- 0
    lp <- x %*% coefs + offset
  }
  
  if (any(class(object) %in% "glm")) {
    family <- object$family$family
    linkinv <- object$family$linkinv
    mu <- linkinv(lp)
    
    if (family == "gaussian") {
      dispersion <- object$dispersion
      logL <- dnorm(y, lp, sqrt(dispersion), log = TRUE)
    }
    if (family == "binomial") {
      logL <- dbinom(y, 1, mu, log = TRUE)
    }
    if (family == "poisson") {
      logL <- dpois(y, mu, log = TRUE)
    }
    if (family == "Gamma") {
      library(MASS)
      shape <- gamma.shape(model)$alpha
      logL <- dgamma(y, shape = shape, scale = fitted(model, type = "response"), log = TRUE)
    }
    if (any(class(object) %in% "negbin")) {
      logL <- dnbinom(y, size = object$nb.theta, mu = mu, log = TRUE)
    }
    logL <- sum(logL, na.rm = TRUE)
    deviance <- -2 * logL
    
    mse <- mean((y - mu)^2, na.rm = TRUE)
    mae <- mean(abs(y - mu), na.rm = TRUE)
    measures <- list(deviance = deviance, mse = mse, mae = mae)
    if (family == "gaussian") {
      R2 <- (var(y, na.rm = TRUE) - mse)/var(y, na.rm = TRUE)
      measures <- list(deviance = deviance, mse = mse, R2 = R2)
    }
    if (family == "binomial") {
      nna <- !is.na(y)&!is.na(mu)
      auc <- roc(y[nna], mu[nna], plot = FALSE)$AUC
      misclassification <- mean(abs(y - mu) >= 0.5, na.rm = TRUE)
      measures <- list(deviance = deviance, auc = auc, mse = mse, 
                       misclassification = misclassification)
    }
    out <- list(lp = lp, y.fitted = mu, measures = unlist(measures))
  }
  
  if (any(class(object) %in% "coxph")) {
    library(survival)
    if (!is.Surv(y)) stop("'y' should be a Surv object")
    if (is.null(object$method)) object$method <- "breslow" 
    pl <- coxph(y ~ lp, init = 1, control = coxph.control(iter.max=1), method = object$method)$loglik[1]
    nna <- !is.na(y)&!is.na(lp)
    cindex <- Cindex(y[nna], lp[nna])$cindex
    measures <- list(loglik = pl, Cindex = cindex)
    out <- list(lp = lp, measures = unlist(measures))
  }
  
  if (any(class(object) %in% "polr")) {
    library(MASS)
    if (missing(new.x) | missing(new.y)) {
      y <- object$model[, 1]
      pred <- predict(object, type = "probs")
    }
    else {
      y <- new.y
      pred <- predict(object, newdata = new.x, type = "probs")
    }
    if (is.vector(pred)) pred <- t(as.matrix(pred))
    auc <- mse <- misclassification <- 0
    y.level <- levels(object$model[, 1])
    for (k in 1:NCOL(pred)) {
      y1 <- ifelse(y == y.level[k], 1, 0)
      auc <- auc + roc(y1, pred[, k], plot = FALSE)$AUC
      misclassification <- misclassification + mean(abs(y1 - pred[, k]) > 0.5, na.rm = TRUE)
      mse <- mse + mean((y1 - pred[, k])^2, na.rm = TRUE)
    }
    auc <- auc/NCOL(pred)
    mse <- mse/NCOL(pred)
    misclassification <- misclassification/NCOL(pred)
    L <- rep(NA, NROW(pred))
    for (i in 1:NROW(pred)){
      y2 <- rep(0, NCOL(pred))
      for (k in 1:NCOL(pred)) y2[k] <- ifelse(y[i]==y.level[k], 1, 0)
      L[i] <- sum(y2*pred[i,])
    }
    L <- ifelse(L==0, 1e-04, L)
    deviance <- -2 * sum(log(L))
    measures <- list(deviance = deviance, auc = auc, mse = mse, misclassification = misclassification)
    
    out <- list(lp = lp, y.fitted = pred, measures = unlist(measures))
  }
  
  out
}

#*******************************************************************************

roc <- function(dn, pre, m = 100, plot = TRUE, add = FALSE, xlab = "False positive rate", ylab = "True positive rate",
                lwd = 2, lty = 1, col = "black", type = "s", pch = 20)
{
  # draw roc curve
  n <- length(dn)                   # sample size
  d <- length(dn[dn != 0])          # number of disease (dn=1)
  sr <- (max(pre) - min(pre))/m     # size of reclassifying interval
  tpf <- rep(NA, m)                 # true positive fraction
  fpf <- rep(NA, m)                 # false positive fraction
  for (i in 1:(m + 1)){
    tpf[i] <- sum(pre >= max(pre) - sr*(i - 1) & dn == 1)/d
    fpf[i] <- sum(pre >= max(pre) - sr*(i - 1) & dn == 0)/(n-d)
  }
  alpha <- max(pre) - sr*c(0:m)
  
  if (add) plot <- TRUE
  if (plot){
    if(!add) plot(c(0,1), c(0,1), xlim = c(0, 1), ylim = c(0, 1), xlab = xlab, ylab = ylab,
                  type = "l", lty = 3, col = "gray")    # draw a diagonal line
    lines(fpf, tpf, type = type, lwd = lwd, lty = lty, col = col, pch = pch)
  }
  
  # calculate area under curve based on non-parametric statistic (Mann-Whitney U)
  tp2 <- rep(0, m)                  # number of true positive for each interval of cut-off values
  fp2 <- rep(0, m)                  # number of false positive for each interval of cut-off values
  for (i in 1:m){
    tp2[i] <- sum((pre >= min(pre) + sr*(i - 1) & pre < min(pre) + sr * (i)) & dn == 1)
    fp2[i] <- sum((pre >= min(pre) + sr*(i - 1) & pre < min(pre) + sr * (i)) & dn == 0)
  }
  
  dtp2 <- rep(0, m)                 # degression of tp2
  afp2 <- rep(0, m)                 # acumulation of fp2
  dtp2[1] <- (d - tp2[1])
  for (i in 1:(m - 1)){
    dtp2[i + 1] <- dtp2[i] - tp2[i + 1]
    afp2[i + 1] <- afp2[i] + fp2[i]
  }
  
  a <- rep(0, m)
  for (i in 1:m) {a[i] <- fp2[i] * dtp2[i] + (fp2[i] * tp2[i]) / 2}
  auc <- sum(a) / (d * (n - d) + 1e-06)     # area under curve
  if (auc <= 0) auc <- 0.5
  
  # test hypothesis of auc=0.5 (Mann-Whitney U test)
  q1 <- rep(0, m)                   # degression (leijian) of tp2
  q2 <- rep(0, m)                   # acumulation (leijia) of fp2
  for (i in 1:m){
    q1[i] <- fp2[i] * ((dtp2[i])^2 + tp2[i] * dtp2[i] + ((tp2[i])^2) / 3)
    q2[i] <- tp2[i] * ((afp2[i])^2 + fp2[i] * afp2[i] + ((fp2[i])^2) / 3)
  }
  sq1 <- sum(q1) / (d^2 * (n - d) + 1e-06)
  sq2 <- sum(q2) / (d * (n - d)^2 + 1e-06)
  se <- z <- p <- lci <- rci <- NULL
  se <- (auc * (1 - auc) + (d - 1) * (sq1 - auc^2) + ((n - d) - 1) * (sq2 - auc^2)) / (d * (n - d) + 1e-06)
  if(se > 0){
    se <- sqrt(se)
    z <- (auc - 0.5) / se             # z score
    p <- 2 * pnorm(-abs(z))           # p-value for two-tailed test
    lci <- auc - 1.96 * se            # left boundary of 95% confidence interval
    rci <- auc + 1.96 * se            # right boundary of 95% confidence interval
  }
  w = list(alpha = alpha, TPF = tpf, FPF = fpf, AUC = auc, SE = se, 
           Test.statistics = z, P.value = p, CI = c(lci, rci))
  w
}

#*******************************************************************************